Assignment submitted by Kshitiz Sethia (N13773746, ks3839)

This is the readme file

to build: run "build.cmd"
to run:
	put 30 numbers in "numbers.txt" file
	run "run.cmd"
	find the output in "log.txt"
to clean after you are done: run "clean.cmd"
